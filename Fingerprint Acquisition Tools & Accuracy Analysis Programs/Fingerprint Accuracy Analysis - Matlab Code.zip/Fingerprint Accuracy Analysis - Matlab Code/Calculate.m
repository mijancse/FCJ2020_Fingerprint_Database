%% Code of Fingerprint Accuracy Analysis - 50 Students
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate.m
% The 6th impression of a finger is verified against the template database containing 5 templates for each finger. 
% The fingerprint template database file is “CSE_v7_1000_imprs.mat”. The verification query images are stored in 
% “Accuracy Test Query Images (_6 images) - Updated v2” directory. After executing the program, 
% we get the matching accuracy data called “Match_Score” that is stored in “200_fingers_matching_info_v2.mat” file.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
load('CSE_v7_1000_imprs.mat'); 
path = 'H:\Education\Thesis\Data Accquisition Experiment\Img Pool - Refined\Accuracy Test Query Images (_6 images) - Updated v2';
% path = pwd;
% display(pwd);
files = dir(fullfile(path, '*.bmp'));
%%
Match_Score=zeros(200,5);
%% GET FILE
for z=1:200
    file=fullfile(path, files(z).name);
    I = imread(file);
    m = size(I,1); 
    n = size(I,2);
    % Mixed Code [Segmentation , Normalization]
    Img = before_enhancement(I); %manually cut 4 sides of the picture
    EnhancedImg =  fft_enhance_cubs(Img,-1); % if -1, 12x12
    blksze = 5;   thresh = 0.085;   % FVC2002 DB1
    [I_Normalized, Mask, maskind] = segment_normalize_by_NA(EnhancedImg, blksze, thresh);
                %Mask = after_mask(Mask); %manually cut 4 sides of the picture
    % Orientation Est
    I_Oriented=ridgeorient(I_Normalized, 1, 3, 3);
    % Ridge Frequency
    [I_Ridge_Freq, MedianFreq] = ridgefreq_by_NA(I_Normalized, Mask, I_Oriented, 32, 5, 5, 15);
    % BINARIZATION
    ModifiedMask=Mask.*MedianFreq;
    I_Binarized = ridgefilter_by_NA(I_Normalized, I_Oriented, ModifiedMask, 0.5, 0.5, 1) > 0;
    % THINNING
    I_Thinned =  bwmorph(~I_Binarized, 'thin',Inf);
    % EXTRACT MINUTIAES
    [Minutiae1, Min_path_index] = extract_minutiaes(I_Thinned, I, Mask, I_Oriented);

    %% OPERATION
    filename=files(z).name;
    FINGER_IDX=filename(10:10);
    SID=filename(1:8);
    Max_Match_Score=0;
    ChoosenTemplateIndex=zeros(1,5,'uint16');
    k=1;
    for i=1:size(Templates,1)
        student_id = Templates{i,2}; 
        if strcmp(Templates{i,3},num2str(FINGER_IDX))==1 && strcmp(student_id,SID)==1
            ChoosenTemplateIndex(k)=i;
            k=k+1;
        end
    end

    S=zeros(size(ChoosenTemplateIndex,2),1);
    for i=1:size(ChoosenTemplateIndex,2)
        Match_Score(z,i)=match(Minutiae1,Templates{ChoosenTemplateIndex(i)});
    end
    display(['Finger : ' num2str(z)])
    drawnow
end